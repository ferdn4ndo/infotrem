
**Easy jQuery PHP Captcha**

=============================================================

Setup a Captcha in seconds.

- Integrated with jQuery Validate plugin
- Use custom fonts
- Unique secure back-end generated captcha (PHP)
- No reCaptcha pain.

=============================================================

**Demo**

http://jquery4u.com/demos/easy-jquery-php-captcha/

Powered by: jQuery, jQuery.validate, Require.js, Backbone.js, Bootstrap

=============================================================

**Download**

https://github.com/sdeering/easy-jquery-php-captcha

=============================================================

**Setup**

http://jquery4u.com/validation/easy-jquery-php-captcha/

=============================================================

**Credits**

jQuery4u

Sam Deering

99points

=============================================================
